import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:power_maids/Utils/color_style.dart';
import 'package:power_maids/Utils/global_text.dart';
import 'package:power_maids/app/modules/NotificationScreen/controllers/notification_screen_controller.dart';
import 'package:power_maids/app/modules/NotificationScreen/notification_list_ui.dart';

class NotificationScreenView extends GetView<NotificationScreenController> {
  const NotificationScreenView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          surfaceTintColor: AppStyles.backgroundColor,

          automaticallyImplyLeading: false,
          elevation: 1,
          backgroundColor: AppStyles.backgroundColor,
          title: Textwidget(
            text: "Notification",
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
          centerTitle: false,
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Textwidget(
                      text:
                          "You have ${controller.ImagesList.length} notification",
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Flexible(
                    child: IconButton(
                      onPressed: () {},
                      icon: Textwidget(
                        text: "Mark all as read",
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: NotificationListUI(
                imagesList: controller.ImagesList,
                nameList: controller.NameList,
                titleList: controller.TitleList,
                dateList: controller.DateList,
                timeList: controller.TimeList,
              ),
            )
          ],
        ));
  }
}
