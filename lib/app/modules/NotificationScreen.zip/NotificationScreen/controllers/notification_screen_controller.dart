import 'package:get/get.dart';

class NotificationScreenController extends GetxController {
  //TODO: Implement NotificationScreenController

  final count = 0.obs;

  final ImagesList = [
    "assets/images/nImageone.png",
    "assets/images/nImagetwo.png",



  ];
  final NameList = [
    "Amber Julia", "Barbara Michelle"



  ];
  final TitleList = [
    'confirmed your booking request',
    'confirmed your booking request',


  ];
  final DateList = [

    'Mon, Oct 16',
    'Mon, Oct 16',


  ];
  final TimeList = [

    "10:00 PM",
    "10:00 PM",


  ];


  final NotificationItems = {
    'ImagesList': [

    ],
    'NameList': [],
    'TitleList': [

    ],
    'DateList': [
      'Mon, Oct 16',
      'Mon, Oct 16',
    ],
    'TimeList': [
      "10:00 PM",
    ],
  };

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
